package com.sms.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentManagementWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentManagementWebApplication.class, args);
	}

}
